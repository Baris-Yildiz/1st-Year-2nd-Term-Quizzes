public class ParameterException extends RuntimeException {
    public ParameterException(String message) {
        super(message);
    }
}

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {

        FileWriter output = new FileWriter("output.txt", true);

        try {

            if (args.length != 1) {
                throw new ParameterException("There should be only 1 paremeter\n");
            }

            String path = args[0];
            List<String> inputLines;

            try {
                inputLines = Files.readAllLines(Paths.get(path));
            } catch (IOException e) {
                throw new FileNotFoundException("There should be an input file in the specified path\n");
            }

            if (inputLines.size() == 0) {
                throw new EmptyInputFileException("The input file should not be empty\n");
            }

            StringBuilder outputStream = new StringBuilder();

            for (String inputLine : inputLines) {
                for (int i = 0; i < inputLine.length(); i++) {

                    int asciiValueOfChar = inputLine.toLowerCase().charAt(i);

                    if ((asciiValueOfChar < 97 || asciiValueOfChar > 123) && asciiValueOfChar != 32) {
                        throw new InputException("The input file should not contains unexpected characters\n");
                    }
                }

                outputStream.append(inputLine).append("\n");
            }

            output.write(outputStream.toString());

        } catch (ParameterException | FileNotFoundException | InputException | EmptyInputFileException e) {
            output.write(e.getMessage());
        } finally {
            output.close();
        }
    }
}
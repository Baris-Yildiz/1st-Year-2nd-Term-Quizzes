import java.time.LocalTime;
import java.time.format.DateTimeParseException;

public class Main {
    public static void main(String[] args) {
        // input and output files
        String inputFile = args[0];
        String outputFile = args[1];

        try{
            //reading the input
            String[] inputTrips = FileIO.readFile(inputFile);

            //exception handling
            if(inputTrips == null){
                throw new AssertionError("Cannot find the input file.");
            } else if (inputTrips.length > 100) {
                throw new AssertionError("Input size is larger than 100.");
            }

            // converting the inputs into trip objects and doing more exception handling.
            TripSchedule tripSchedule = new TripSchedule();
            for (int i = 0; i < inputTrips.length; i++) {
                String[] inputTripContents = inputTrips[i].split("\t");
                if(inputTripContents.length != 3){
                    throw new AssertionError("Too few or too much data about one of the trips.");
                }
                Trip trip = new Trip(inputTripContents[0], LocalTime.parse(inputTripContents[1]), Integer.parseInt(inputTripContents[2]));
                if(trip.duration < 0){
                    throw new NumberFormatException();
                }
                tripSchedule.trips[i] = trip;
                trip.calculateArrival();
            }

            // preparing the output.
            StringBuilder stringBuilder = new StringBuilder();
            TripController tripController = new TripController();

            Trip[] trips = tripSchedule.trips;
            tripController.DepartureSchedule(tripSchedule);
            stringBuilder.append("Departure order:\n");

            // determining the departure states.
            Trip currentTrip;
            Trip otherTrip;
            for (int i = 0; i < inputTrips.length; i++) {
                currentTrip = trips[i];
                for (int j = 0; j < inputTrips.length; j++) {
                    otherTrip = trips[j];
                    if(currentTrip.getDepartureTime() == otherTrip.getDepartureTime() && (i!=j)){
                        currentTrip.setState("DELAYED");
                        break;
                    }
                }
                stringBuilder.append(currentTrip.tripName).append(" depart at ").append(currentTrip.departureTime).append("   Trip State:").append(currentTrip.getState()).append("\n");
            }


            tripController.ArrivalSchedule(tripSchedule);
            stringBuilder.append("\nArrival order:\n");

            // determining the arrival states.
            for (int i = 0; i < inputTrips.length; i++) {
                currentTrip = trips[i];
                currentTrip.setState("IDLE");
                for (int j = 0; j < inputTrips.length; j++) {
                    otherTrip = trips[j];
                    if(currentTrip.getArrivalTime() == otherTrip.getArrivalTime() && (i!=j)){
                        currentTrip.setState("DELAYED");
                        break;
                    }
                }
                stringBuilder.append(currentTrip.tripName).append(" arrive at ").append(currentTrip.arrivalTime).append("   Trip State:").append(currentTrip.getState()).append("\n");
            }

            // finalizing the output and writing to the output file.
            stringBuilder.deleteCharAt(stringBuilder.length() - 1);
            FileIO.writeFile(outputFile, stringBuilder.toString());

        }catch (AssertionError assertionError){
            System.out.println(assertionError.getMessage());
        }catch(DateTimeParseException dateTimeParseException){
            System.out.println("Invalid departure time on at least one of the trips.");
        }catch (NumberFormatException numberFormatException){
            System.out.println("Invalid duration on at least one of the trips.");
        }
    }
}
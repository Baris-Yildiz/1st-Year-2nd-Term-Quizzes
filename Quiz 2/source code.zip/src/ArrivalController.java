public interface ArrivalController {
    /**
     * sorts Trips based on their arrivalTime, in ascending order.
     * @param tripSchedule: the tripSchedule object to provide the array containing Trip objects.
     */
    public void ArrivalSchedule(TripSchedule tripSchedule);
}

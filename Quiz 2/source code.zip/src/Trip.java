import java.time.LocalTime;
public class Trip {
    public String tripName;
    public LocalTime departureTime;
    public LocalTime arrivalTime = LocalTime.MIN;
    public int duration;
    public String state;    // idle or delayed depending on whether the trip's arrival or departure time overlaps with another trip.

    public Trip(String tripName, LocalTime departureTime, int duration){
        this.tripName = tripName;
        this.departureTime = departureTime;
        this.duration = duration;
        setState("IDLE");
    }

    // returns the departure time as minutes past from the start of day.
    public int getDepartureTime() {
        return departureTime.getMinute() + departureTime.getHour() * 60;
    }

    // returns the arrival time as minutes past from the start of day.
    public int getArrivalTime() {
        return getDepartureTime() + duration;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public void calculateArrival(){
        int totalMinutes = departureTime.getMinute() + duration;
        int arrivalHour = (departureTime.getHour() + totalMinutes/60) % 24;
        String arrivalHourString = arrivalHour < 10 ? "0" + arrivalHour : Integer.toString(arrivalHour);
        int arrivalMinute = totalMinutes % 60;
        String arrivalMinuteString = arrivalMinute < 10 ? "0" + arrivalMinute : Integer.toString(arrivalMinute);
        arrivalTime = LocalTime.parse(arrivalHourString + ":" + arrivalMinuteString);
    }
}

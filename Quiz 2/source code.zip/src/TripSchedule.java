import java.time.LocalTime;

public class TripSchedule {
    Trip[] trips = new Trip[100];

    // constructor initializes the array with default Trip objects.
    public TripSchedule(){
        for(int i = 0; i < 100; i++){
            trips[i] = new Trip("0", LocalTime.parse("00:00"), 0);
        }
    }
}

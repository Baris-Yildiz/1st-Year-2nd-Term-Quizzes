public interface DepartureController {
    /**
     * sorts Trips based on their departureTime, in ascending order.
     * @param tripSchedule : the tripSchedule object to provide the array containing Trip objects.
     */
    public void DepartureSchedule(TripSchedule tripSchedule);
}

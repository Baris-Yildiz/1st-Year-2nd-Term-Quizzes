import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class FileIO {

    // returns the contents of the file at path in the form of a String array
    public static String[] readFile(String path){
        try {
            List<String> fileContents = Files.readAllLines(Paths.get(path));

            int length = fileContents.size();
            String[] results = new String[length];

            int i = 0;
            for (String fileContent : fileContents) {
                results[i++] = fileContent;
            }
            return results;
        } catch (IOException ioException) {
            ioException.printStackTrace();
            return null;
        }
    }

    // writes content to the file at path.
    public static void writeFile(String path, String content) {
        PrintStream ps = null;
        try {
            ps = new PrintStream(new FileOutputStream(path));
            ps.print(content);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            if (ps != null) { //Flushes all the content and closes the stream if it has been successfully created.
                ps.flush();
                ps.close();
            }
        }
    }
}


public class TripController implements ArrivalController, DepartureController{
    @Override
    public void DepartureSchedule(TripSchedule tripSchedule) {
        Trip[] trips = tripSchedule.trips;
        boolean swapped;
        Trip temp;

        do{
            swapped = false;
            for (int i = 0; i < trips.length-1; i++) {
                if(!trips[i+1].tripName.equals("0") && trips[i].getDepartureTime() > trips[i+1].getDepartureTime()){
                    swapped = true;
                    temp = trips[i+1];
                    trips[i+1] = trips[i];
                    trips[i] = temp;
                }
            }
        }while(swapped);
    }

    @Override
    public void ArrivalSchedule(TripSchedule tripSchedule) {
        Trip[] trips = tripSchedule.trips;
        boolean swapped;
        Trip temp;

        do{
            swapped = false;
            for (int i = 0; i < trips.length-1; i++) {
                if(!trips[i+1].tripName.equals("0") && trips[i].getArrivalTime() > trips[i+1].getArrivalTime()){
                    swapped = true;
                    temp = trips[i+1];
                    trips[i+1] = trips[i];
                    trips[i] = temp;
                }
            }
        }while(swapped);
    }
}


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {

        String inputFile = args[0];
        Scanner inputStream = new Scanner(new File(inputFile));

        IDComparator<String> idComparator = new IDComparator<>();

        String currentVerse;
        while(inputStream.hasNextLine()) {
            currentVerse = inputStream.nextLine();

            Containers.addVerse(currentVerse);
        }

        FileWriter poemArrayListFile = new FileWriter("poemArrayList.txt");

        String output = Containers.getCollectionContent(Containers.getVerseArrayList());
        Containers.writeContainerContentToFile(poemArrayListFile, output);


        FileWriter poemOrderedArrayListFile = new FileWriter("poemArrayListOrderByID.txt");

        Collections.sort(Containers.getVerseArrayList(), idComparator);

        output = Containers.getCollectionContent(Containers.getVerseArrayList());
        Containers.writeContainerContentToFile(poemOrderedArrayListFile, output);


        FileWriter poemHashSetFile = new FileWriter("poemHashSet.txt");

        output = Containers.getCollectionContent(Containers.getVerseHashSet());
        Containers.writeContainerContentToFile(poemHashSetFile, output);


        FileWriter poemTreeSetFile = new FileWriter("poemTreeSet.txt");

        output = Containers.getCollectionContent(Containers.getVerseTreeSet());
        Containers.writeContainerContentToFile(poemTreeSetFile, output);


        FileWriter poemOrderedTreeSetFile = new FileWriter("poemTreeSetOrderedByID.txt");
        output = Containers.getOrderedTreeSetContent(idComparator);

        Containers.writeContainerContentToFile(poemOrderedTreeSetFile, output);


        FileWriter poemHashMapFile = new FileWriter("poemHashMap.txt");

        output = Containers.getMapContent();
        Containers.writeContainerContentToFile(poemHashMapFile, output);

    }
}
import java.util.Comparator;

public class IDComparator<T extends String> implements Comparator<T> {

    @Override
    public int compare(T first, T second) {
        int firstId = Integer.parseInt(first.split("\t")[0]);
        int secondId = Integer.parseInt(second.split("\t")[0]);
        return firstId - secondId;
    }
}

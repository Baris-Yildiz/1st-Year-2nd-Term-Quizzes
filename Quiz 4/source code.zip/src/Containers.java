
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Containers {
    private static final ArrayList<String> verseArrayList = new ArrayList<>();
    private static final HashSet<String> verseHashSet = new HashSet<>();
    private static final TreeSet<String> verseTreeSet = new TreeSet<>();
    private static final HashMap<Integer, String> verseHashMap = new HashMap<>();

    public static void addVerse(String verse) {
        verseArrayList.add(verse);
        verseHashSet.add(verse);
        verseTreeSet.add(verse);
        String[] items = verse.split("\t");
        verseHashMap.put(Integer.parseInt(items[0]), items[1]);
    }

    public static String getCollectionContent(Collection<String> collection) {

        StringBuilder content = new StringBuilder();
        for (String item : collection) {
            content.append(item).append("\n");
        }

        return content.toString();
    }

    public static String getMapContent() {
        StringBuilder content = new StringBuilder();

        for (Integer key : verseHashMap.keySet()) {
            content.append(key).append("\t").append(verseHashMap.get(key)).append("\n");
        }

        return content.toString();
    }

    public static String getOrderedTreeSetContent(Comparator<String> comparator) {
        TreeSet<String> orderedTreeSet = new TreeSet<>(comparator);
        orderedTreeSet.addAll(verseTreeSet);

        return getCollectionContent(orderedTreeSet);
    }
    public static void writeContainerContentToFile(FileWriter file, String content) throws IOException {
        file.write(content);
        file.close();
    }

    public static ArrayList<String> getVerseArrayList() {
        return verseArrayList;
    }
    public static HashSet<String> getVerseHashSet() {
        return verseHashSet;
    }
    public static TreeSet<String> getVerseTreeSet() {
        return verseTreeSet;
    }

}

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        String inputFilePath = args[0];
        String outputFilePath = "output.txt";

        String[] inputContents = FileIO.readFile(inputFilePath);

        int lineNumber = 0;
        int upperLimit;
        StringBuilder stringBuilder = new StringBuilder();
        ArrayList<Integer> numbersToSort = new ArrayList<>();

        while(!inputContents[lineNumber].equals("Exit")){
            switch (inputContents[lineNumber]){
                case "Armstrong numbers up to:":
                    upperLimit = Integer.parseInt(inputContents[++lineNumber]);
                    stringBuilder.append("Armstrong numbers up to ").append(upperLimit).append(":\n").append(Numbers.returnArmstrongNumbersUntil(upperLimit)).append("\n\n");
                    break;
                case "Emirp numbers up to:":
                    upperLimit = Integer.parseInt(inputContents[++lineNumber]);
                    stringBuilder.append("Emirp numbers up to ").append(upperLimit).append(":\n").append(Numbers.returnEmirpNumbersUntil(upperLimit)).append("\n\n");
                    break;
                case "Abundant numbers up to:":
                    upperLimit = Integer.parseInt(inputContents[++lineNumber]);
                    stringBuilder.append("Abundant numbers up to ").append(upperLimit).append(":\n").append(Numbers.returnAbundantNumbersUntil(upperLimit)).append("\n\n");
                    break;
                case "Ascending order sorting:":
                    numbersToSort.clear();
                    while(Integer.parseInt(inputContents[++lineNumber]) != -1){
                        numbersToSort.add(Integer.parseInt(inputContents[lineNumber]));
                    }
                    stringBuilder.append("Ascending order sorting:\n").append(Sorting.generateSortedSequenceOfNumbers(numbersToSort, true)).append("\n");
                    break;
                case "Descending order sorting:":
                    numbersToSort.clear();
                    while(Integer.parseInt(inputContents[++lineNumber]) != -1){
                        numbersToSort.add(Integer.parseInt(inputContents[lineNumber]));
                    }

                    stringBuilder.append("Descending order sorting:\n").append(Sorting.generateSortedSequenceOfNumbers(numbersToSort, false)).append("\n");
                    break;
            }
            lineNumber++;
        }

        stringBuilder.append("Finished...");
        FileIO.writeFile(outputFilePath, stringBuilder.toString());
    }
}

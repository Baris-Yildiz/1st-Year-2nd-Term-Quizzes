import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class FileIO {

    /**
     *
     * @param path path of the input file
     * @return the contents of the file as a String array.
     */
    public static String[] readFile(String path){

        try {
            List<String> fileContents = Files.readAllLines(Paths.get(path));

            int length = fileContents.size();
            String[] results = new String[length];

            int i = 0;
            for (String fileContent : fileContents) {
                results[i++] = fileContent;
            }
            return results;
        } catch (IOException ioException) {
            ioException.printStackTrace();
            return null;
        }
    }

    /**
     * writes contents to a file
     * @param path path of the output file
     * @param content contents to be written
     */

    public static void writeFile(String path, String content) {
        /*
        path: path of the output file.
        content: content to be written to the file
        writes content to the file.
         */
        PrintStream ps = null;
        try {
            ps = new PrintStream(new FileOutputStream(path));
            ps.print(content);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } finally {
            if (ps != null) { //Flushes all the content and closes the stream if it has been successfully created.
                ps.flush();
                ps.close();
            }
        }
    }
}

import java.util.ArrayList;
import java.util.stream.Collectors;

public class Numbers {

    /**
     *
     * @param number
     * @return the length of "number"
     */
    static int returnLengthOfNumber(int number){
        if(number / 10 == 0) {
            return 1;
        }
        else{
            return returnLengthOfNumber(number/10) + 1;
        }
    }

    /**
     *
     * @param number
     * @return whether number is a prime number
     */
    static boolean isPrime(int number){
        for(int i = 2; i <= Math.sqrt(number); i++){
            if(number % i == 0){
                return false;
            }
        }
        return true;
    }

    /**
     *
     * @param upperLimit the inclusive upper range
     * @return armstrong numbers up to upperLimit
     */
    public static String returnArmstrongNumbersUntil(int upperLimit){
        ArrayList<Integer> results = new ArrayList<>();

        for(int i = 1; i <= upperLimit; i++){
            int sum = 0;
            int temp = i;
            int digits = returnLengthOfNumber(i);
            for(int j = 0; j < digits; j++){
                sum += Math.pow(temp%10,digits);
                temp/=10;
            }
            if(sum == i){
                results.add(i);
            }
        }
        return results.stream().map(Object::toString).collect(Collectors.joining(" "));
    }

    /**
     *
     * @param upperLimit the inclusive upper range
     * @return emirp numbers up to upperLimit
     */
    public static String returnEmirpNumbersUntil(int upperLimit){
        ArrayList<Integer> results = new ArrayList<>();
        for(int i = 13; i <= upperLimit; i++){
            int temp = i;
            if(isPrime(i)){
                int digits = returnLengthOfNumber(i);
                int reversed = 0;
                for(int j = 1; j<=digits; j++){
                    reversed += (temp%10) * Math.pow(10, digits-j);
                    temp/=10;
                }
                if(isPrime(reversed) && i != reversed){
                    results.add(i);
                }
            }
        }
        return results.stream().map(Object::toString).collect(Collectors.joining(" "));
    }

    /**
     *
     * @param upperLimit the inclusive upper range
     * @return abundant numbers up to upperLimit
     */
    public static String returnAbundantNumbersUntil(int upperLimit){
        ArrayList<Integer> results = new ArrayList<>();
        for(int i = 1; i <= upperLimit; i++){
            int sum = 1;
            for(int j = 2; j<Math.sqrt(i); j++){
                if (i % j == 0){
                    sum += (j + i/j);
                }
            }
            if(sum > i){
                results.add(i);
            }
        }

        return results.stream().map(Object::toString).collect(Collectors.joining(" "));
    }
}

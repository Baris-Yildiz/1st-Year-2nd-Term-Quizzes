import java.util.ArrayList;
import java.util.stream.Collectors;

public class Sorting {
    /**
     *
     * @param unsortedArray array that is to be sorted
     * @param ascending ascending or descending order?
     * @return the sorted elements with each step shown.
     */
    public static String generateSortedSequenceOfNumbers(ArrayList<Integer> unsortedArray, boolean ascending){
        ArrayList<Integer> sortedArray = new ArrayList<>();
        int firstNumberToBeAdded = unsortedArray.get(0);
        sortedArray.add(firstNumberToBeAdded);

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(firstNumberToBeAdded).append("\n");

        for (int i = 1; i < unsortedArray.size(); i++) {
            int numberToBeAdded = unsortedArray.get(i);

            for(int j = 0; j < sortedArray.size(); j++){
                if ((ascending && sortedArray.get(j) > numberToBeAdded) || (!ascending && sortedArray.get(j) < numberToBeAdded)){
                    sortedArray.add(j, numberToBeAdded);
                    break;
                }
            }
            if(sortedArray.size() != i+1){
                sortedArray.add(numberToBeAdded);
            }

            stringBuilder.append(sortedArray.stream().map(Object::toString).collect(Collectors.joining(" "))).append("\n");
        }


        return stringBuilder.toString();
    }

}

import java.util.Locale;

public class Palindrome {

    public static boolean isPalindrome(String string) {
        MyStack<Character> myStack = new MyStack<>();

        StringBuilder stringBuilder = new StringBuilder();

        for (int i = 0; i < string.length(); i++) {

            if (Character.isLetter(string.charAt(i))) {
                stringBuilder.append(string.toLowerCase(Locale.US).charAt(i));
            }
        }


        for (int i = 0; i < stringBuilder.length(); i++) {

            if (i < stringBuilder.length()/2) {
                myStack.push(new Node<>(stringBuilder.charAt(i)));
            } else if (i == stringBuilder.length()/2 && stringBuilder.length() % 2 == 1) {
                continue;
            } else if (!myStack.pop().getData().equals(stringBuilder.charAt(i)) ){
                return false;
            }

        }

        return true;
    }


}

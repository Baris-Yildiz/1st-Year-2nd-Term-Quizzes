import java.util.HashMap;
import java.util.Map;

public class BalancedParenthesis {

    public static boolean isValid(String string) {
        MyStack<Character> myStack = new MyStack<>();
        Map<Character, Character> inverseOfParenthesis = new HashMap<>();
        inverseOfParenthesis.put(')', '(');
        inverseOfParenthesis.put(']', '[');
        inverseOfParenthesis.put('}', '{');


        for (int i = 0; i < string.length(); i++) {
            Character currentChar = string.charAt(i);

            if (inverseOfParenthesis.containsValue(currentChar)) {
                myStack.push(new Node<>(currentChar));
            } else if (inverseOfParenthesis.containsKey(currentChar)) {
                if (myStack.getLast() == null) {
                    return false;
                }
                if (!myStack.pop().getData().equals(inverseOfParenthesis.get(currentChar))) {
                    return false;
                }
            }
        }

        return myStack.getLast() == null;
    }



}

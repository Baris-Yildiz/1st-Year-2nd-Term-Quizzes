public class MyQueue<T> {

    private Node<T> firstNode;
    private Node<T> lastNode;


    public void enqueue(Node<T> node) {

        if (lastNode != null) {

            lastNode.setNext(node);
            node.setPrev(lastNode);
        } else {
            firstNode = node;
        }

        lastNode = node;

    }

    public void dequeue() {

        if (firstNode != null) {

            Node<T> next = firstNode.getNext();

            if (next != null) {
                next.setPrev(null);
                firstNode.setNext(null);
            }

            firstNode = next;
        }

        if (firstNode == null) {
            lastNode = null;
        }


    }

    public Node<T> getFirstNode() {
        return firstNode;
    }

}

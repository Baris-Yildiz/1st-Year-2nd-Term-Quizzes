public class MyStack<T> {
    private Node<T> last;

    public void push(Node<T> node) {

        if (last != null) {
            last.setNext(node);
            node.setPrev(last);
        }

        last = node;
    }

    public Node<T> pop() {

        Node<T> returnee = last;

        if (last != null) {

            Node<T> prev = last.getPrev();

            if (prev != null) {
                last.setPrev(null);
                prev.setNext(null);
            }

            last = prev;
        }

        return returnee;
    }

    public Node<T> getLast() {
        return last;
    }

}

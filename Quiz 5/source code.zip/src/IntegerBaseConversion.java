import java.io.FileWriter;
import java.io.IOException;

public class IntegerBaseConversion {

    public static void convertToBinary(int decimal, FileWriter fileWriter) throws IOException {

        MyStack<Integer> myStack = new MyStack<>();

        if (decimal == 0) {
            fileWriter.write(Integer.toString(decimal));
            return;
        } else if (decimal < 0) {
            decimal = -decimal;
            fileWriter.write("-");
        }

        while (decimal > 0) {
            myStack.push(new Node<>(decimal % 2));

            decimal /= 2;
        }

        while (myStack.getLast() != null) {
            fileWriter.write(myStack.pop().getData().toString());
        }

    }

}

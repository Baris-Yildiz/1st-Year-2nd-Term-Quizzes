import java.io.FileWriter;
import java.io.IOException;

public class BinaryCounting {

    public static void countUpTo(int bound, FileWriter fileWriter) throws IOException {

        MyQueue<String> binaryQueue = new MyQueue<>();

        binaryQueue.enqueue(new Node<>("1"));

        if (bound > 0) {
            fileWriter.write("\t");
        }

        for (int i = 0; i < bound; i++) {

            Node<String> firstNode = binaryQueue.getFirstNode();

            fileWriter.write(firstNode.getData());
            binaryQueue.dequeue();

            binaryQueue.enqueue(new Node<>(firstNode.getData() + "0"));
            binaryQueue.enqueue(new Node<>(firstNode.getData() + "1"));

            if (i == bound-1) {
                break;
            }

            fileWriter.write("\t");
        }

    }
}

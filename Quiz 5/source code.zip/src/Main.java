import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class Main {

    public static void main(String[] args) throws IOException {


        List<String> inputLines = Files.readAllLines(Paths.get(args[0]));
        FileWriter outputFile = new FileWriter(args[1]);

        for (String inputLine : inputLines) {

            String[] contents = inputLine.split("\t");

            switch (contents[0]) {
                case "Convert from Base 10 to Base 2:":

                    outputFile.write("Equivalent of " + Integer.parseInt(contents[1]) + " (base 10) in base 2 is: ");
                    IntegerBaseConversion.convertToBinary(Integer.parseInt(contents[1]), outputFile);
                    outputFile.write("\n");

                    break;
                case "Count from 1 up to n in binary:":

                    outputFile.write("Counting from 1 up to " + Integer.parseInt(contents[1]) + " in binary:");
                    BinaryCounting.countUpTo(Integer.parseInt(contents[1]), outputFile);
                    outputFile.write("\n");

                    break;
                case "Check if following is palindrome or not:":

                    if (Palindrome.isPalindrome(contents[1])) {
                        outputFile.write("\"" + contents[1] + "\" is a palindrome.\n");
                    } else {
                        outputFile.write("\"" + contents[1] + "\" is not a palindrome.\n");
                    }
                    break;

                case "Check if following expression is valid or not:":

                    if (BalancedParenthesis.isValid(contents[1])) {
                        outputFile.write("\"" + contents[1] + "\" is a valid expression.\n");
                    } else {
                        outputFile.write("\"" + contents[1] + "\" is not a valid expression.\n");
                    }
                    break;

            }

        }

        outputFile.close();
    }
}